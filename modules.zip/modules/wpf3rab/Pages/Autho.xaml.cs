﻿using HashPasswords;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace wpf3rab.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autho.xaml
    /// </summary>
    public partial class Autho : Page
    {
        private DispatcherTimer timer;
        DateTime dataTime = new DateTime();
        public Autho()
        {
            InitializeComponent();
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
        }
        /// <summary>
        /// Обработчик нажатия на кнопку "Войти как гость"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEnterGuests_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client(null));
        }
        public string vremya = DateTime.Now.ToString("HH:mm:ss");// Передаем время в данный момент в переменную
        private int cap = 0;// Переменая которая содержит кол-во попыток входа
        private int times = 10;// Переменная которая содержит кол-во секунд блокировки входа после неудачной попытки
        private int attempts = 3;
        /// <summary>
        /// Обработчик нажатия на кнопку "Войти"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {

            string login = txtbLogin.Text.Trim();
            string password = pswbPassword.Password.Trim();
            string hashPassword = HashPassvords.HashPassword(password);// Хэшируется пароль
            if (login.Length > 0 && password.Length > 0)// Проверка на заполнение полей логина и пароля
            {
                if (cap < 1)// Проверка количества попыток входа
                {
                    Models.Entities5 db = Helper.getContext(); // Подлючение к базе данных
                    var user = Helper.getContext().Autorizacia.Where(u => u.Login == login && u.Parol == hashPassword).FirstOrDefault();/*Создание обьекта, 
                                                                                                                                         который представляет 
                                                                                                                                         запись в базе данных
                                                                                                                                         */
                    DateTime time = DateTime.Parse(vremya);
                    if (time.TimeOfDay >= new TimeSpan(10, 0, 0) && time.TimeOfDay < new TimeSpan(19, 0, 0))// Проверка на рабочее время
                    {
                        if (user != null)// Проверка на существование пользователя
                        {
                            var id = Helper.getContext().Sotrudnik.Where(id1 => id1.ID_Sotrudnik == user.ID_Sotrudnik).FirstOrDefault();// Получение ID должности пользователя
                            var asd = id.Doljnost;
                            attempts = 3;
                            if (asd.Nazvanie_dooljnosti == "Администратор")
                            {
                                string imya = id.Imya;
                                string famil = id.Familya;
                                string otchsetv = id.Otchestvo;
                                Admin admin = new Admin(imya, famil, otchsetv, vremya);
                                NavigationService.Navigate(admin);
                            }
                            else if (asd.Nazvanie_dooljnosti == "Бухгалтер")
                            {
                                string imya = id.Imya;
                                string famil = id.Familya;
                                string otchsetv = id.Otchestvo;
                                Buhg buhg = new Buhg(imya, famil, otchsetv, vremya);
                                NavigationService.Navigate(buhg);
                            }
                            else if (asd.Nazvanie_dooljnosti == "Прораб")
                            {
                                string imya = id.Imya;
                                string famil = id.Familya;
                                string otchsetv = id.Otchestvo;
                                Prorab prorab = new Prorab(imya, famil, otchsetv, vremya);
                                NavigationService.Navigate(prorab);
                            }
                            else if(asd.Nazvanie_dooljnosti == "Директор")
                            {
                                string imya = id.Imya;
                                string famil = id.Familya;
                                string otchsetv = id.Otchestvo;
                                Director director = new Director(imya, famil, otchsetv, vremya);
                                NavigationService.Navigate(director);
                            }
                            else if(asd.Nazvanie_dooljnosti == "Водитель")
                            {
                                string imya = id.Imya;
                                string famil = id.Familya;
                                string otchsetv = id.Otchestvo;
                                Vodetil voditel = new Vodetil(imya, famil, otchsetv, vremya);
                                NavigationService.Navigate(voditel);

                            }
                            else if(asd.Nazvanie_dooljnosti == "Шахтер")
                            {
                                string imya = id.Imya;
                                string famil = id.Familya;
                                string otchsetv = id.Otchestvo;
                                Shahter shahter = new Shahter(imya, famil, otchsetv, vremya);
                                NavigationService.Navigate(shahter);
                            }

                        }
                        else
                        {
                            if (attempts > 1)// После неудачного входа пользователь должен пройти капчу
                            {
                                attempts--;
                                MessageBox.Show($"Такой пользователь не найден\n Пройдите Капчу. У вас осталось {attempts} попытки для верного ввода данных!");
                                cap++;
                                txtBlockCaptcha.Text = GenerateRandomCaptcha(4);// Вывод капчи
                            }
                            else// Если пользователь 3 раза не смог войти в систему его блокируют на 10 секунд
                            {
                                txtbLogin.IsEnabled = false;
                                pswbPassword.IsEnabled = false;
                                txtbLogin.Clear();
                                pswbPassword.Clear();
                                times = 10;
                                LbTimer.Content = time.ToString();
                                timer.Start();
                                LbTimer.Foreground = Brushes.Red;
                                LbTimer.Content = "Осталось секунд до разблокировки: 10";
                                attempts = 3;
                                MessageBox.Show("Вы заблокированы на 10 секунд");

                            }
                        }
                    }

                    else// Если время превышает 19:00
                    {
                        txtbLogin.Clear();
                        pswbPassword.Clear();
                        MessageBox.Show("Возвращайтесь завтра, хватит работать!");
                    }
                }
                else
                {
                    var user = Helper.getContext().Autorizacia.Where(u => u.Login == login && u.Parol == password).FirstOrDefault();
                    string captcha = txtboxCaptcha.Text;
                    if (captcha == txtBlockCaptcha.Text)// Проверка на правильность ввода капче
                    {
                        TextLogin.Text = "Логин:";               
                        TextPassword.Text = "Пароль:";
                        txtBlockCaptcha.Visibility = Visibility.Collapsed;
                        txtboxCaptcha.Visibility = Visibility.Collapsed;
                        txtbLogin.Visibility = Visibility.Visible;
                        pswbPassword.Visibility = Visibility.Visible;
                        txtBlockCaptcha.TextDecorations = null;
                        txtBlockCaptcha.FontStyle = FontStyles.Normal;
                        txtbLogin.Clear();
                        pswbPassword.Clear();
                        txtboxCaptcha.Clear();// Происходит очистка полей и открывается доступ пользователю на вход
                        cap--;
                        MessageBox.Show("Капча введена верно, попробуйте авторизироваться еще раз");

                    }
                    else// При неправильном вводе капчи генерируется новая
                    {
                        MessageBox.Show("Капча введена неверно");
                        txtboxCaptcha.Text = "";
                        txtBlockCaptcha.Text = GenerateRandomCaptcha(4);
                    }
                }

                }
                else
                {
                    MessageBox.Show("Не все поля заполнены! Заполните поля логина и пароля!");
                }
            }
        
        /// <summary>
        /// Метод для запуска таймера и последующей разблокировки
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Timer_Tick(object sender, EventArgs e)
        {
            LbTimer.Content = "";
            times--;
            Panel.Visibility = Visibility.Hidden;
            LbTimer.Content = "Осталось секунд до разблокировки: \n                           " + times.ToString();
            if (times == 0)
            {
                LbTimer.Content = "";
                timer.Stop();
                txtbLogin.IsEnabled = true;
                pswbPassword.IsEnabled = true;
                MessageBox.Show("Вы разблокированы");
                Panel.Visibility = Visibility.Visible;
            }
        }
        /// <summary>
        /// Метод для генерации рандомной капчи
        /// </summary>
        /// <param name="length"></param>
        /// <returns></returns>
        private string GenerateRandomCaptcha(int length)
        {
            TextLogin.Text = "";
            TextPassword.Text = "Введи зачёркнутый текст";
            txtbLogin.Visibility = Visibility.Collapsed;
            pswbPassword.Visibility = Visibility.Collapsed;
            txtboxCaptcha.Visibility = Visibility.Visible;
            txtBlockCaptcha.Visibility = Visibility.Visible;

            txtBlockCaptcha.TextDecorations = TextDecorations.Strikethrough;

            txtBlockCaptcha.FontStyle = FontStyles.Italic;

            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
            Random random = new Random();
            return new string(Enumerable.Repeat(chars, length).Select(s => s[random.Next(s.Length)]).ToArray());
        }
        private void FrmAutho_ContentRendered(object sender, EventArgs e)
        {
        
        }
    }
}
