
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 01/13/2024 15:21:10
-- Generated from EDMX file: G:\modules\wpf3rab\Models\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [22.106-02-GornoDobivayushiyKombinat];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_Autorizacia_Sotrudnik]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Autorizacia] DROP CONSTRAINT [FK_Autorizacia_Sotrudnik];
GO
IF OBJECT_ID(N'[dbo].[FK_Grafik_rabot_Smena]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Grafik_rabot] DROP CONSTRAINT [FK_Grafik_rabot_Smena];
GO
IF OBJECT_ID(N'[dbo].[FK_Grafik_rabot_Sotrudnik]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Grafik_rabot] DROP CONSTRAINT [FK_Grafik_rabot_Sotrudnik];
GO
IF OBJECT_ID(N'[dbo].[FK_Otchet_smeni_Metalli]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Otchet_smeni] DROP CONSTRAINT [FK_Otchet_smeni_Metalli];
GO
IF OBJECT_ID(N'[dbo].[FK_Otchet_smeni_Smena]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Otchet_smeni] DROP CONSTRAINT [FK_Otchet_smeni_Smena];
GO
IF OBJECT_ID(N'[dbo].[FK_Pasport_Pol]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Pasport] DROP CONSTRAINT [FK_Pasport_Pol];
GO
IF OBJECT_ID(N'[dbo].[FK_Pasport_Propiska]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Pasport] DROP CONSTRAINT [FK_Pasport_Propiska];
GO
IF OBJECT_ID(N'[dbo].[FK_Smena_Mesta_dobichi]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Smena] DROP CONSTRAINT [FK_Smena_Mesta_dobichi];
GO
IF OBJECT_ID(N'[dbo].[FK_Smena_Smotryashiy]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Smena] DROP CONSTRAINT [FK_Smena_Smotryashiy];
GO
IF OBJECT_ID(N'[dbo].[FK_Smotryashiy_Sotrudnik]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Smotryashiy] DROP CONSTRAINT [FK_Smotryashiy_Sotrudnik];
GO
IF OBJECT_ID(N'[dbo].[FK_Sotrudnik_Doljnost]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Sotrudnik] DROP CONSTRAINT [FK_Sotrudnik_Doljnost];
GO
IF OBJECT_ID(N'[dbo].[FK_Zayavki_na_oborudovanie_Oborudovanie]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Zayavki_na_oborudovanie] DROP CONSTRAINT [FK_Zayavki_na_oborudovanie_Oborudovanie];
GO
IF OBJECT_ID(N'[dbo].[FK_Zayavki_na_oborudovanie_Postavshiki]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Zayavki_na_oborudovanie] DROP CONSTRAINT [FK_Zayavki_na_oborudovanie_Postavshiki];
GO
IF OBJECT_ID(N'[dbo].[FK_Zayavki_na_oborudovanie_Sotrudnik]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Zayavki_na_oborudovanie] DROP CONSTRAINT [FK_Zayavki_na_oborudovanie_Sotrudnik];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Autorizacia]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Autorizacia];
GO
IF OBJECT_ID(N'[dbo].[Doljnost]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Doljnost];
GO
IF OBJECT_ID(N'[dbo].[Grafik_rabot]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Grafik_rabot];
GO
IF OBJECT_ID(N'[dbo].[Mesta_dobichi]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Mesta_dobichi];
GO
IF OBJECT_ID(N'[dbo].[Metalli]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Metalli];
GO
IF OBJECT_ID(N'[dbo].[Oborudovanie]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Oborudovanie];
GO
IF OBJECT_ID(N'[dbo].[Otchet_smeni]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Otchet_smeni];
GO
IF OBJECT_ID(N'[dbo].[Pasport]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Pasport];
GO
IF OBJECT_ID(N'[dbo].[Pol]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Pol];
GO
IF OBJECT_ID(N'[dbo].[Postavshiki]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Postavshiki];
GO
IF OBJECT_ID(N'[dbo].[Propiska]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Propiska];
GO
IF OBJECT_ID(N'[dbo].[Smena]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Smena];
GO
IF OBJECT_ID(N'[dbo].[Smotryashiy]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Smotryashiy];
GO
IF OBJECT_ID(N'[dbo].[Sotrudnik]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Sotrudnik];
GO
IF OBJECT_ID(N'[dbo].[sysdiagrams]', 'U') IS NOT NULL
    DROP TABLE [dbo].[sysdiagrams];
GO
IF OBJECT_ID(N'[dbo].[vid_mestorozhdeniya]', 'U') IS NOT NULL
    DROP TABLE [dbo].[vid_mestorozhdeniya];
GO
IF OBJECT_ID(N'[dbo].[Zayavki_na_oborudovanie]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Zayavki_na_oborudovanie];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Autorizacia'
CREATE TABLE [dbo].[Autorizacia] (
    [ID_Avtorizaciya] int IDENTITY(1,1) NOT NULL,
    [ID_Sotrudnik] int  NULL,
    [Login] nvarchar(max)  NULL,
    [Parol] nvarchar(max)  NULL
);
GO

-- Creating table 'Doljnost'
CREATE TABLE [dbo].[Doljnost] (
    [ID_Doljnost] int IDENTITY(1,1) NOT NULL,
    [Nazvanie_dooljnosti] nvarchar(100)  NULL
);
GO

-- Creating table 'Grafik_rabot'
CREATE TABLE [dbo].[Grafik_rabot] (
    [ID_Grafik_rabot] int IDENTITY(1,1) NOT NULL,
    [ID_Smena] int  NULL,
    [ID_Sotrudnik] int  NULL
);
GO

-- Creating table 'Mesta_dobichi'
CREATE TABLE [dbo].[Mesta_dobichi] (
    [ID_Mesta_dobichi] int IDENTITY(1,1) NOT NULL,
    [ID_Vid_Mestorozhdenia] nvarchar(100)  NULL,
    [Gorod] nvarchar(50)  NULL
);
GO

-- Creating table 'Metalli'
CREATE TABLE [dbo].[Metalli] (
    [ID_Metalla] int IDENTITY(1,1) NOT NULL,
    [Nazvanie_metalla] nvarchar(50)  NULL,
    [Plotnost_metalla] nvarchar(50)  NULL
);
GO

-- Creating table 'Oborudovanie'
CREATE TABLE [dbo].[Oborudovanie] (
    [ID_Oborudovaniya] int IDENTITY(1,1) NOT NULL,
    [Nazvaie_oborudovaniya] int  NULL
);
GO

-- Creating table 'Otchet_smeni'
CREATE TABLE [dbo].[Otchet_smeni] (
    [ID_Otchet_smeni] int IDENTITY(1,1) NOT NULL,
    [ID_Smeni] int  NULL,
    [ID_Metalla] int  NULL,
    [Kolichestvo_dobitogo_metalla] nvarchar(50)  NULL,
    [Kolichestvo_rabotnikov] int  NULL
);
GO

-- Creating table 'Pasport'
CREATE TABLE [dbo].[Pasport] (
    [ID_Pasport] int IDENTITY(1,1) NOT NULL,
    [Imya] nvarchar(50)  NULL,
    [Familiya] nvarchar(50)  NULL,
    [Otchestvo] nvarchar(50)  NULL,
    [Data_rozhdenia] datetime  NULL,
    [Data_vidachy] datetime  NULL,
    [Kem_vidan] nvarchar(100)  NULL,
    [Nomer] int  NULL,
    [Seria] int  NULL,
    [ID_Propiska] int  NULL,
    [ID_Pol] int  NULL
);
GO

-- Creating table 'Pol'
CREATE TABLE [dbo].[Pol] (
    [ID_Pol] int IDENTITY(1,1) NOT NULL,
    [Pol1] nvarchar(50)  NULL
);
GO

-- Creating table 'Postavshiki'
CREATE TABLE [dbo].[Postavshiki] (
    [ID_Postavshika_oborudovaniya] int IDENTITY(1,1) NOT NULL,
    [Nazvanie_postavshika] nvarchar(100)  NULL
);
GO

-- Creating table 'Propiska'
CREATE TABLE [dbo].[Propiska] (
    [ID_Propiska] int IDENTITY(1,1) NOT NULL,
    [Region] nvarchar(50)  NULL,
    [Rayon] nvarchar(50)  NULL,
    [Punkt] nvarchar(50)  NULL,
    [Ulitca] nvarchar(50)  NULL,
    [Dom] nvarchar(50)  NULL,
    [Data_registracii] datetime  NULL
);
GO

-- Creating table 'Smena'
CREATE TABLE [dbo].[Smena] (
    [ID_Smena] int IDENTITY(1,1) NOT NULL,
    [ID_Mesta_dobichi] int  NULL,
    [Data_nachala] datetime  NULL,
    [Data_konca] datetime  NULL,
    [ID_Smotryashiy] int  NULL
);
GO

-- Creating table 'Smotryashiy'
CREATE TABLE [dbo].[Smotryashiy] (
    [ID_Smotryashiy] int IDENTITY(1,1) NOT NULL,
    [ID_Sotrudnik] int  NULL,
    [Imya_naznachivshego] nvarchar(50)  NULL,
    [Familiya_naznachivshego] nvarchar(50)  NULL,
    [Otchestvo_naznachivshego] nvarchar(50)  NULL,
    [Data_naznacheniya] datetime  NULL
);
GO

-- Creating table 'Sotrudnik'
CREATE TABLE [dbo].[Sotrudnik] (
    [ID_Sotrudnik] int IDENTITY(1,1) NOT NULL,
    [Imya] nvarchar(50)  NULL,
    [Familya] nvarchar(50)  NULL,
    [Otchestvo] nvarchar(50)  NULL,
    [ID_Pol] int  NULL,
    [Oklad] decimal(19,4)  NULL,
    [Nomer_telephona] nvarchar(50)  NULL,
    [Email] nvarchar(100)  NULL,
    [Data_nachala_rabot] datetime  NULL,
    [Data_uvolneniya] nvarchar(50)  NULL,
    [ID_Doljnost] int  NULL
);
GO

-- Creating table 'sysdiagrams'
CREATE TABLE [dbo].[sysdiagrams] (
    [name] nvarchar(128)  NOT NULL,
    [principal_id] int  NOT NULL,
    [diagram_id] int IDENTITY(1,1) NOT NULL,
    [version] int  NULL,
    [definition] varbinary(max)  NULL
);
GO

-- Creating table 'vid_mestorozhdeniya'
CREATE TABLE [dbo].[vid_mestorozhdeniya] (
    [ID_Vid_mestorozhdeniya] int IDENTITY(1,1) NOT NULL,
    [Vid_mestorozhdeniya1] nvarchar(100)  NULL
);
GO

-- Creating table 'Zayavki_na_oborudovanie'
CREATE TABLE [dbo].[Zayavki_na_oborudovanie] (
    [ID_Zayavki_na_zakaz_oborudovaniya] int IDENTITY(1,1) NOT NULL,
    [ID_Postavshika_oborudovaniya] int  NULL,
    [ID_oborudovaniya] int  NULL,
    [Kolichestvo_postavlyaemogo_oborudovaniya] int  NULL,
    [ID_Sotrudnik] int  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [ID_Avtorizaciya] in table 'Autorizacia'
ALTER TABLE [dbo].[Autorizacia]
ADD CONSTRAINT [PK_Autorizacia]
    PRIMARY KEY CLUSTERED ([ID_Avtorizaciya] ASC);
GO

-- Creating primary key on [ID_Doljnost] in table 'Doljnost'
ALTER TABLE [dbo].[Doljnost]
ADD CONSTRAINT [PK_Doljnost]
    PRIMARY KEY CLUSTERED ([ID_Doljnost] ASC);
GO

-- Creating primary key on [ID_Grafik_rabot] in table 'Grafik_rabot'
ALTER TABLE [dbo].[Grafik_rabot]
ADD CONSTRAINT [PK_Grafik_rabot]
    PRIMARY KEY CLUSTERED ([ID_Grafik_rabot] ASC);
GO

-- Creating primary key on [ID_Mesta_dobichi] in table 'Mesta_dobichi'
ALTER TABLE [dbo].[Mesta_dobichi]
ADD CONSTRAINT [PK_Mesta_dobichi]
    PRIMARY KEY CLUSTERED ([ID_Mesta_dobichi] ASC);
GO

-- Creating primary key on [ID_Metalla] in table 'Metalli'
ALTER TABLE [dbo].[Metalli]
ADD CONSTRAINT [PK_Metalli]
    PRIMARY KEY CLUSTERED ([ID_Metalla] ASC);
GO

-- Creating primary key on [ID_Oborudovaniya] in table 'Oborudovanie'
ALTER TABLE [dbo].[Oborudovanie]
ADD CONSTRAINT [PK_Oborudovanie]
    PRIMARY KEY CLUSTERED ([ID_Oborudovaniya] ASC);
GO

-- Creating primary key on [ID_Otchet_smeni] in table 'Otchet_smeni'
ALTER TABLE [dbo].[Otchet_smeni]
ADD CONSTRAINT [PK_Otchet_smeni]
    PRIMARY KEY CLUSTERED ([ID_Otchet_smeni] ASC);
GO

-- Creating primary key on [ID_Pasport] in table 'Pasport'
ALTER TABLE [dbo].[Pasport]
ADD CONSTRAINT [PK_Pasport]
    PRIMARY KEY CLUSTERED ([ID_Pasport] ASC);
GO

-- Creating primary key on [ID_Pol] in table 'Pol'
ALTER TABLE [dbo].[Pol]
ADD CONSTRAINT [PK_Pol]
    PRIMARY KEY CLUSTERED ([ID_Pol] ASC);
GO

-- Creating primary key on [ID_Postavshika_oborudovaniya] in table 'Postavshiki'
ALTER TABLE [dbo].[Postavshiki]
ADD CONSTRAINT [PK_Postavshiki]
    PRIMARY KEY CLUSTERED ([ID_Postavshika_oborudovaniya] ASC);
GO

-- Creating primary key on [ID_Propiska] in table 'Propiska'
ALTER TABLE [dbo].[Propiska]
ADD CONSTRAINT [PK_Propiska]
    PRIMARY KEY CLUSTERED ([ID_Propiska] ASC);
GO

-- Creating primary key on [ID_Smena] in table 'Smena'
ALTER TABLE [dbo].[Smena]
ADD CONSTRAINT [PK_Smena]
    PRIMARY KEY CLUSTERED ([ID_Smena] ASC);
GO

-- Creating primary key on [ID_Smotryashiy] in table 'Smotryashiy'
ALTER TABLE [dbo].[Smotryashiy]
ADD CONSTRAINT [PK_Smotryashiy]
    PRIMARY KEY CLUSTERED ([ID_Smotryashiy] ASC);
GO

-- Creating primary key on [ID_Sotrudnik] in table 'Sotrudnik'
ALTER TABLE [dbo].[Sotrudnik]
ADD CONSTRAINT [PK_Sotrudnik]
    PRIMARY KEY CLUSTERED ([ID_Sotrudnik] ASC);
GO

-- Creating primary key on [diagram_id] in table 'sysdiagrams'
ALTER TABLE [dbo].[sysdiagrams]
ADD CONSTRAINT [PK_sysdiagrams]
    PRIMARY KEY CLUSTERED ([diagram_id] ASC);
GO

-- Creating primary key on [ID_Vid_mestorozhdeniya] in table 'vid_mestorozhdeniya'
ALTER TABLE [dbo].[vid_mestorozhdeniya]
ADD CONSTRAINT [PK_vid_mestorozhdeniya]
    PRIMARY KEY CLUSTERED ([ID_Vid_mestorozhdeniya] ASC);
GO

-- Creating primary key on [ID_Zayavki_na_zakaz_oborudovaniya] in table 'Zayavki_na_oborudovanie'
ALTER TABLE [dbo].[Zayavki_na_oborudovanie]
ADD CONSTRAINT [PK_Zayavki_na_oborudovanie]
    PRIMARY KEY CLUSTERED ([ID_Zayavki_na_zakaz_oborudovaniya] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [ID_Sotrudnik] in table 'Autorizacia'
ALTER TABLE [dbo].[Autorizacia]
ADD CONSTRAINT [FK_Autorizacia_Sotrudnik]
    FOREIGN KEY ([ID_Sotrudnik])
    REFERENCES [dbo].[Sotrudnik]
        ([ID_Sotrudnik])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Autorizacia_Sotrudnik'
CREATE INDEX [IX_FK_Autorizacia_Sotrudnik]
ON [dbo].[Autorizacia]
    ([ID_Sotrudnik]);
GO

-- Creating foreign key on [ID_Doljnost] in table 'Sotrudnik'
ALTER TABLE [dbo].[Sotrudnik]
ADD CONSTRAINT [FK_Sotrudnik_Doljnost]
    FOREIGN KEY ([ID_Doljnost])
    REFERENCES [dbo].[Doljnost]
        ([ID_Doljnost])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Sotrudnik_Doljnost'
CREATE INDEX [IX_FK_Sotrudnik_Doljnost]
ON [dbo].[Sotrudnik]
    ([ID_Doljnost]);
GO

-- Creating foreign key on [ID_Smena] in table 'Grafik_rabot'
ALTER TABLE [dbo].[Grafik_rabot]
ADD CONSTRAINT [FK_Grafik_rabot_Smena]
    FOREIGN KEY ([ID_Smena])
    REFERENCES [dbo].[Smena]
        ([ID_Smena])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Grafik_rabot_Smena'
CREATE INDEX [IX_FK_Grafik_rabot_Smena]
ON [dbo].[Grafik_rabot]
    ([ID_Smena]);
GO

-- Creating foreign key on [ID_Sotrudnik] in table 'Grafik_rabot'
ALTER TABLE [dbo].[Grafik_rabot]
ADD CONSTRAINT [FK_Grafik_rabot_Sotrudnik]
    FOREIGN KEY ([ID_Sotrudnik])
    REFERENCES [dbo].[Sotrudnik]
        ([ID_Sotrudnik])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Grafik_rabot_Sotrudnik'
CREATE INDEX [IX_FK_Grafik_rabot_Sotrudnik]
ON [dbo].[Grafik_rabot]
    ([ID_Sotrudnik]);
GO

-- Creating foreign key on [ID_Mesta_dobichi] in table 'Smena'
ALTER TABLE [dbo].[Smena]
ADD CONSTRAINT [FK_Smena_Mesta_dobichi]
    FOREIGN KEY ([ID_Mesta_dobichi])
    REFERENCES [dbo].[Mesta_dobichi]
        ([ID_Mesta_dobichi])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Smena_Mesta_dobichi'
CREATE INDEX [IX_FK_Smena_Mesta_dobichi]
ON [dbo].[Smena]
    ([ID_Mesta_dobichi]);
GO

-- Creating foreign key on [ID_Metalla] in table 'Otchet_smeni'
ALTER TABLE [dbo].[Otchet_smeni]
ADD CONSTRAINT [FK_Otchet_smeni_Metalli]
    FOREIGN KEY ([ID_Metalla])
    REFERENCES [dbo].[Metalli]
        ([ID_Metalla])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Otchet_smeni_Metalli'
CREATE INDEX [IX_FK_Otchet_smeni_Metalli]
ON [dbo].[Otchet_smeni]
    ([ID_Metalla]);
GO

-- Creating foreign key on [ID_oborudovaniya] in table 'Zayavki_na_oborudovanie'
ALTER TABLE [dbo].[Zayavki_na_oborudovanie]
ADD CONSTRAINT [FK_Zayavki_na_oborudovanie_Oborudovanie]
    FOREIGN KEY ([ID_oborudovaniya])
    REFERENCES [dbo].[Oborudovanie]
        ([ID_Oborudovaniya])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Zayavki_na_oborudovanie_Oborudovanie'
CREATE INDEX [IX_FK_Zayavki_na_oborudovanie_Oborudovanie]
ON [dbo].[Zayavki_na_oborudovanie]
    ([ID_oborudovaniya]);
GO

-- Creating foreign key on [ID_Smeni] in table 'Otchet_smeni'
ALTER TABLE [dbo].[Otchet_smeni]
ADD CONSTRAINT [FK_Otchet_smeni_Smena]
    FOREIGN KEY ([ID_Smeni])
    REFERENCES [dbo].[Smena]
        ([ID_Smena])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Otchet_smeni_Smena'
CREATE INDEX [IX_FK_Otchet_smeni_Smena]
ON [dbo].[Otchet_smeni]
    ([ID_Smeni]);
GO

-- Creating foreign key on [ID_Pol] in table 'Pasport'
ALTER TABLE [dbo].[Pasport]
ADD CONSTRAINT [FK_Pasport_Pol]
    FOREIGN KEY ([ID_Pol])
    REFERENCES [dbo].[Pol]
        ([ID_Pol])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Pasport_Pol'
CREATE INDEX [IX_FK_Pasport_Pol]
ON [dbo].[Pasport]
    ([ID_Pol]);
GO

-- Creating foreign key on [ID_Propiska] in table 'Pasport'
ALTER TABLE [dbo].[Pasport]
ADD CONSTRAINT [FK_Pasport_Propiska]
    FOREIGN KEY ([ID_Propiska])
    REFERENCES [dbo].[Propiska]
        ([ID_Propiska])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Pasport_Propiska'
CREATE INDEX [IX_FK_Pasport_Propiska]
ON [dbo].[Pasport]
    ([ID_Propiska]);
GO

-- Creating foreign key on [ID_Postavshika_oborudovaniya] in table 'Zayavki_na_oborudovanie'
ALTER TABLE [dbo].[Zayavki_na_oborudovanie]
ADD CONSTRAINT [FK_Zayavki_na_oborudovanie_Postavshiki]
    FOREIGN KEY ([ID_Postavshika_oborudovaniya])
    REFERENCES [dbo].[Postavshiki]
        ([ID_Postavshika_oborudovaniya])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Zayavki_na_oborudovanie_Postavshiki'
CREATE INDEX [IX_FK_Zayavki_na_oborudovanie_Postavshiki]
ON [dbo].[Zayavki_na_oborudovanie]
    ([ID_Postavshika_oborudovaniya]);
GO

-- Creating foreign key on [ID_Smotryashiy] in table 'Smena'
ALTER TABLE [dbo].[Smena]
ADD CONSTRAINT [FK_Smena_Smotryashiy]
    FOREIGN KEY ([ID_Smotryashiy])
    REFERENCES [dbo].[Smotryashiy]
        ([ID_Smotryashiy])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Smena_Smotryashiy'
CREATE INDEX [IX_FK_Smena_Smotryashiy]
ON [dbo].[Smena]
    ([ID_Smotryashiy]);
GO

-- Creating foreign key on [ID_Sotrudnik] in table 'Smotryashiy'
ALTER TABLE [dbo].[Smotryashiy]
ADD CONSTRAINT [FK_Smotryashiy_Sotrudnik]
    FOREIGN KEY ([ID_Sotrudnik])
    REFERENCES [dbo].[Sotrudnik]
        ([ID_Sotrudnik])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Smotryashiy_Sotrudnik'
CREATE INDEX [IX_FK_Smotryashiy_Sotrudnik]
ON [dbo].[Smotryashiy]
    ([ID_Sotrudnik]);
GO

-- Creating foreign key on [ID_Sotrudnik] in table 'Zayavki_na_oborudovanie'
ALTER TABLE [dbo].[Zayavki_na_oborudovanie]
ADD CONSTRAINT [FK_Zayavki_na_oborudovanie_Sotrudnik]
    FOREIGN KEY ([ID_Sotrudnik])
    REFERENCES [dbo].[Sotrudnik]
        ([ID_Sotrudnik])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Zayavki_na_oborudovanie_Sotrudnik'
CREATE INDEX [IX_FK_Zayavki_na_oborudovanie_Sotrudnik]
ON [dbo].[Zayavki_na_oborudovanie]
    ([ID_Sotrudnik]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------