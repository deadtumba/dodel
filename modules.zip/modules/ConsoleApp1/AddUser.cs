﻿using HashPasswords;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ConsoleApp1.Models1;


namespace ConsoleApp1
{
    /// <summary>
    /// Консольное приложения для добавления пользователя
    /// </summary>
    class AddUser
    {
        /// <summary>
        /// Результатом работы данного метода будет добавление новой записи в таблице базы данных
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args) 
        {
            try
            {
                var dn = Helper1.GetContext();
                Autorizacia autorizacia = new Autorizacia();
                Sotrudnik sotrudnik = new Sotrudnik(); 

                Console.WriteLine("Создание новой учетной записи пользователя \n");
               
                string imya = "";
                while(string.IsNullOrEmpty(imya) || !Regex.IsMatch(imya, "^[а-яА-Я]+$"))
                {
                    Console.Write("Введите имя пользователя:");
                    imya = Console.ReadLine();
                    if (string.IsNullOrEmpty(imya) || !Regex.IsMatch(imya, "^[а-яА-Я]+$"))// Проверка на правильность ввода имени
                    {
                        Console.WriteLine("Некорректно введено имя, попробуйте еще раз");
                    }
                }
                sotrudnik.Imya = imya;// Добавление данных в базу данных
                string famil = "";
                while (string.IsNullOrEmpty(famil) || !Regex.IsMatch(famil, "^[а-яА-Я]+$"))
                {
                    Console.Write("Введите фамилию пользователя:");
                    famil = Console.ReadLine();
                    if (string.IsNullOrEmpty(famil) || !Regex.IsMatch(famil, "^[а-яА-Я]+$"))// Проверка на правильность ввода фамилии
                    {
                        Console.WriteLine("Некорректно введено фамилия, попробуйте еще раз");
                    }
                }
                sotrudnik.Familya = famil;
                string othes = "";
                while (string.IsNullOrEmpty(othes) || !Regex.IsMatch(othes, "^[а-яА-Я]+$"))
                {
                    Console.Write("Введите отчество пользователя:");
                    othes = Console.ReadLine();
                    if (string.IsNullOrEmpty(othes) || !Regex.IsMatch(othes, "^[а-яА-Я]+$"))// Проверка на правильность ввода отчества
                    {
                        Console.WriteLine("Некорректно введено отчество, попробуйте еще раз");
                    }
                }
                sotrudnik.Otchestvo = othes;
                string oklad = "";
                while (string.IsNullOrEmpty(oklad) || !Regex.IsMatch(oklad, "^[0-9]+$"))
                {
                    Console.Write("Введите оклад пользователя:");
                    oklad = Console.ReadLine();
                    if (string.IsNullOrEmpty(oklad) || !Regex.IsMatch(oklad, "^[0-9]+$"))// Проверка на правильность ввода оклада
                    {
                        Console.WriteLine("Некорректно введен оклад, попробуйте еще раз");
                    }
                }
                sotrudnik.Oklad = Convert.ToDecimal(oklad);
                string mail = "";
                while (string.IsNullOrEmpty(mail) || !Regex.IsMatch(mail, "^[a-zA-Z@.com]+$"))
                {
                    Console.Write("Введите почту пользователя:");
                    mail = Console.ReadLine();
                    if (string.IsNullOrEmpty(mail) || !Regex.IsMatch(mail, "^[a-zA-Z@.com]+$"))// Проверка на правильность ввода почты
                    {
                        Console.WriteLine("Некорректно введена почта, попробуйте еще раз");
                    }
                }
                sotrudnik.Email = mail;
                Console.WriteLine("Выберите должность пользователя (1 - Шахтер. 2 - Администратор. 3 - Бухгалтер. 4 - Водитель. 5 - Прораб): ");
                int dolj = Convert.ToInt32(Console.ReadLine());
                sotrudnik.ID_Doljnost = dolj;
                Console.WriteLine("Выберите пол пользователя (1 - Мужчина. 2 - Женщина.): ");
                int pol = Convert.ToInt32(Console.ReadLine());
                sotrudnik.ID_Pol = pol;
                string number = "";
                while (string.IsNullOrEmpty(number) || !Regex.IsMatch(number, "(\\+7 | 8 |\\b)[\\(\\s -]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[)\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)"))
                {
                    Console.Write("Введите телефон пользователя:");
                    number = Console.ReadLine();
                    if (string.IsNullOrEmpty(number) || !Regex.IsMatch(number, "(\\+7 | 8 |\\b)[\\(\\s -]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[)\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)[\\s-]*(\\d)"))// Проверка на правильность ввода телефона
                    {
                        Console.WriteLine("Некорректно введен телефон, попробуйте еще раз");
                    }
                }
                sotrudnik.Nomer_telephona = number;
                string login = "";
                while (string.IsNullOrEmpty(login) || !Regex.IsMatch(login, "^[а-яА-Я0-9]+$"))
                {
                    Console.Write("Введите логин пользователя:");
                    login = Console.ReadLine();
                    if (string.IsNullOrEmpty(login) || !Regex.IsMatch(login, "^[а-яА-Я0-9]+$"))// Проверка на правильность ввода логина
                    {
                        Console.WriteLine("Некорректно введен логин, попробуйте еще раз");
                    }
                }
                autorizacia.Login = login;
                string passw = "";
                while (string.IsNullOrEmpty(passw) || !Regex.IsMatch(passw, "^[а-яА-Я0-9a-zA-z]+$"))
                {
                    Console.Write("Введите пароль пользователя:");
                    passw = Console.ReadLine();
                    if (string.IsNullOrEmpty(passw) || !Regex.IsMatch(passw, "^[а-яА-Я0-9a-zA-z]+$"))// Проверка на правильность ввода пароля
                    {
                        Console.WriteLine("Некорректно введен пароль, попробуйте еще раз");
                    }
                }
                DateTime data = DateTime.Now;// Получение даты добавления пользователя
                sotrudnik.Data_nachala_rabot = data.Date;
                autorizacia.ID_Sotrudnik = sotrudnik.ID_Sotrudnik;
                string hashPassword = HashPassvords.HashPassword(passw);// Хэширование пароля
                Console.WriteLine("Хэшированный пароль пользователя: {0}",hashPassword);
                autorizacia.Parol = hashPassword; // Добавления пароля в базу данных
                dn.Sotrudnik.Add(sotrudnik);
                dn.Autorizacia.Add(autorizacia);
                dn.SaveChanges();// Сохранение изменений
                Console.WriteLine("Учетная запись успешно добавлена");
                Console.WriteLine("Нажмите Enter чтобы закончить");
                Console.ReadLine();
       

            }
            catch
            {

            }
        }
    }
}
